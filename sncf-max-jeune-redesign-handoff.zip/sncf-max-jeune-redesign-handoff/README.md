# MAX Jeune Planner: redesign handoff

Everything needed to port the approved redesign into the existing app.
The app's logic (`server.js`, `planner.js`, the search/discovery/calendar API calls) is **not** changed.
All changes are in `index.html`.

Live mockups (Design artifact): https://claude.ai/artifact/BE9rX8ttgDMXLioMhQvH6S

## What's in the box

| Path | What it is |
|---|---|
| `IMPLEMENTATION.md` | **Start here.** Step-by-step port, two routes, verification, rollback. |
| `AUDIT.md` | The UX audit: what was wrong, what changed, why. |
| `DESIGN-TOKENS.md` | Colours, type scale, spacing, component specs. |
| `assets/style.css` | The new single stylesheet (replaces all five `<style>` blocks). |
| `assets/body.html` | The new markup. Keeps every element ID your JS uses. |
| `snippets/*.js` | The JS functions that change, one file each, readable and commented by name. |
| `tools/apply_redesign.py` | Builds the new `index.html` from your original, asserting every anchor. |
| `tools/check_ids.py` | Confirms every `$('id')` in the JS exists in the markup. |
| `tests/smoke.py` | Playwright smoke test across all three tabs, dialogs and mobile. |
| `reference/index.original.html` | Your `index.html` as it was when I audited it. |
| `reference/index.redesigned.html` | Output of the script, for diffing. **Smoke-tested in sample mode only.** |
| `design/*.dc.html`, `canvas.json` | Source of the six mockup frames. They need the Design artifact runtime, so open the live link above rather than these files. |
| `screenshots/before`, `after` | Captured from the app in sample mode. |

## Fastest route (about 10 minutes)

```bash
cd "sncf max jeune"
cp index.html index.original.html
python3 /path/to/handoff/tools/apply_redesign.py index.original.html index.html
python3 /path/to/handoff/tools/check_ids.py index.html
SAMPLE_DATA=1 PORT=3000 node server.js     # open http://127.0.0.1:3000
```

Then follow the verification checklist in `IMPLEMENTATION.md` section 4, and test against **real** data before shipping (section 5 explains why).

## Using Claude Code for the port

Open the project in Claude Code and give it this prompt:

> Read `handoff/IMPLEMENTATION.md` and `handoff/AUDIT.md`. Apply the redesign to `index.html` using route A (`tools/apply_redesign.py`), then run `tools/check_ids.py` and `tests/smoke.py`. Don't change `server.js` or `planner.js`. Show me the diff summary and anything the smoke test flags. Then work through the "Known rough edges" list in `IMPLEMENTATION.md` one item at a time, asking me before each.

## What I did and did not verify

Verified: the script applies cleanly to your original `index.html`; the JS parses; every referenced element ID exists; a Playwright run in **sample mode** (5 stations) completed Plan, Explore (one-way, same-day, stepper, limit 0 empty state, "Plan this trip"), Best dates, both dialogs and mobile with no console errors and no horizontal overflow.

Not verified: real SNCF data (hundreds of stations, long journey lists), the Electron build, Safari/Firefox, screen readers, and anything under `server.js`.
