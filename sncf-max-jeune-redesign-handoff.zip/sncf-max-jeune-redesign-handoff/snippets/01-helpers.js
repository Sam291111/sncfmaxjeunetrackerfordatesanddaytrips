/* ===== UI helpers added with the redesign ===== */
let changeLimit=2;
const hour23={hour:'2-digit',minute:'2-digit',hourCycle:'h23'};
const plural=(n,one,many)=>`${n} ${n===1?one:many}`;
const changesLabel=n=>n===0?'Direct':plural(n,'change','changes');
const fmtDur=minutes=>{const m=Math.round(minutes);return `${Math.floor(m/60)}h ${String(m%60).padStart(2,'0')}`;};
const longDate=value=>value?new Date(value+'T12:00:00').toLocaleDateString(undefined,{weekday:'long',day:'numeric',month:'long'}):'';
const spanText=minutes=>Math.round(minutes)>=60?fmtDur(minutes):`${Math.round(minutes)} min`;
function snapshotLabel(d){return d.availabilityDataUpdatedAt?`of ${new Date(d.availabilityDataUpdatedAt).toLocaleString(undefined,{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit',hourCycle:'h23'})}`:`checked ${new Date(d.checkedAt||Date.now()).toLocaleTimeString(undefined,hour23)}`;}
function setProvenance(d){const parts=[freshnessText(d),d.diagnostics?`${d.diagnostics.availableMaxRecords??0} MAX-available origin–destination records checked`:'',d.note].filter(Boolean).map(s=>String(s).trim().replace(/\.+$/,''));$('provenance').textContent=parts.length?parts.join('. ')+'.':'No details available.';}
