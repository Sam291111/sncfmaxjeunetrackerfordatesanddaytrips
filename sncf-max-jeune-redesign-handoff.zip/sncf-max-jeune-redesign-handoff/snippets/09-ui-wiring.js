/* ===== Redesign wiring (dialogs, segmented controls, steppers, tabs) ===== */
function syncEchoes(){for(const [input,echo] of [['outbound','outboundEcho'],['return','returnEcho'],['exploreDate','exploreDateEcho'],['exploreReturnDate','exploreReturnEcho']]){const value=$(input).value;$(echo).textContent=value&&!$(input).closest('.hidden')?longDate(value):'';}}
for(const id of ['outbound','return','exploreDate','exploreReturnDate','exploreMode'])$(id).addEventListener('change',syncEchoes);
function syncPlanOptions(){$('closestOption').classList.toggle('hidden',$('includeTer').checked);}
$('includeTer').addEventListener('change',syncPlanOptions);
function syncDirTabs(which){$('dirOut').setAttribute('aria-selected',String(which==='out'));$('dirBack').setAttribute('aria-selected',String(which==='back'));$('colOut').classList.toggle('is-inactive',which!=='out');$('colBack').classList.toggle('is-inactive',which!=='back');}
$('dirTabs').addEventListener('click',e=>{const b=e.target.closest('[data-dir]');if(b)syncDirTabs(b.dataset.dir);});
function syncSortChips(){const value=$('destinationSort').value;document.querySelectorAll('#sortChips [data-sort]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.sort===value)));}
$('sortChips').addEventListener('click',e=>{const b=e.target.closest('[data-sort]');if(!b||b.disabled)return;$('destinationSort').value=b.dataset.sort;$('destinationSort').dispatchEvent(new Event('change'));});
$('destinationSort').addEventListener('change',syncSortChips);
function setTripMode(mode){$('exploreMode').value=mode;document.querySelectorAll('#tripTypeSeg button').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.mode===mode)));$('exploreMode').dispatchEvent(new Event('change'));}
$('tripTypeSeg').addEventListener('click',e=>{const b=e.target.closest('[data-mode]');if(b)setTripMode(b.dataset.mode);});
function syncStayLabel(){const m=Number($('minimumStayMinutes').value)||0;$('stayOutput').textContent=m<60?`${m} min`:m%60?`${Math.floor(m/60)} h ${m%60}`:`${m/60} h`;}
for(const [id,delta] of [['stayDown',-30],['stayUp',30]])$(id).addEventListener('click',()=>{const input=$('minimumStayMinutes');input.value=String(Math.min(1440,Math.max(0,(Number(input.value)||0)+delta)));syncStayLabel();input.dispatchEvent(new Event('change'));});
for(const [button,from,to] of [['swapStations','origin','destination'],['swapCalendar','calendarOrigin','calendarDestination']])$(button).addEventListener('click',()=>{const a=$(from).value;$(from).value=$(to).value;$(to).value=a;});
for(const [button,dialog] of [['rulesButton','rulesDialog'],['caveatsButton','caveatsDialog']]){$(button).addEventListener('click',()=>$(dialog).showModal());$(dialog).addEventListener('click',e=>{if(e.target===$(dialog))$(dialog).close();});}
document.addEventListener('click',e=>{
 const close=e.target.closest('[data-close-dialog]');if(close){close.closest('dialog').close();return;}
 if(e.target.closest('[data-goto-dates]')){switchView('datesView');if($('calendarOrigin').value&&$('calendarDestination').value)loadCalendar();return;}
 if(e.target.closest('[data-raise-limit]')){setChangeLimit(Math.min(5,changeLimit+1));$('exploreForm').requestSubmit();return;}
 const quick=e.target.closest('[data-quick]');if(quick){$('exploreOrigin').value=quick.dataset.quick;$('exploreOrigin').focus();}
});
document.querySelector('.mode-tabs').addEventListener('keydown',e=>{if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;const tabs=[...document.querySelectorAll('.mode-tab')],i=tabs.indexOf(document.activeElement);if(i<0)return;e.preventDefault();const next=e.key==='Home'?0:e.key==='End'?tabs.length-1:(i+(e.key==='ArrowRight'?1:-1)+tabs.length)%tabs.length;tabs[next].focus();switchView(tabs[next].dataset.view);});
setChangeLimit(2);syncStayLabel();syncPlanOptions();syncEchoes();
