render(d.outbound,'outResults');render(d.returning,'backResults');
$('outRoute').textContent=`${$('origin').value} → ${$('destination').value}`;$('backRoute').textContent=`${$('destination').value} → ${$('origin').value}`;
$('outHeading').innerHTML=`Outbound <span>· ${esc(shortDate($('outbound').value+'T12:00:00'))}</span>`;$('backHeading').innerHTML=`Return <span>· ${esc(shortDate($('return').value+'T12:00:00'))}</span>`;
$('dirOut').textContent=`Outbound · ${$('outResults').querySelectorAll('.journey').length}`;$('dirBack').textContent=`Return · ${$('backResults').querySelectorAll('.journey').length}`;syncDirTabs('out');
$('results').classList.remove('hidden');$('resultKey').classList.remove('hidden');$('planFine').classList.remove('hidden');
const warnings=[d.dayTripWarning,d.eligibilityWarning].filter(Boolean);$('status').className=warnings.length?'status warning':'status';$('status').textContent=warnings.length?warnings.join(' '):`${plural(d.diagnostics?.availableMaxRecords??0,'MAX-available record','MAX-available records')} checked · MAX snapshot ${snapshotLabel(d)}.`;setProvenance(d)
