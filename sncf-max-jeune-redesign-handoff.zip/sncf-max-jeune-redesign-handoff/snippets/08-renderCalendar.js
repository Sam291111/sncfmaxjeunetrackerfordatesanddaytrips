function renderCalendar(data){
 const [year,month]=data.month.split('-').map(Number),offset=(new Date(year,month-1,1).getDay()+6)%7,days=data.days;
 $('calendarHeading').textContent=`${monthName(data.month)} · MAX trains available`;
 const eligibilityCaveat=/bruxelles|brussels/i.test(`${data.origin} ${data.destination}`)?' Brussels MAX €0 eligibility is unconfirmed; SNCF’s published terms do not list Belgium.':'';
 $('calendarStatus').textContent=(data.window.start?`Direct MAX trains for ${data.window.start}–${data.window.end}, MAX snapshot ${snapshotLabel(data)}. Click a day to plan it.`:'No dates in this month fall within the current 30-day availability window.')+eligibilityCaveat;setProvenance(data);
 const headers=['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].map(x=>`<div class="calendar-weekday">${x}</div>`).join(''),blanks=Array.from({length:offset},()=>'<div></div>').join('');
 const cells=days.map(day=>{
  const count=day.availableTrains,level=count===0?0:count<=2?1:count<=5?2:3,blocked=!day.inWindow||count===0,past=day.date<todayIso;
  const state=!day.inWindow?'outside-window':count===0?'no-max':`level-${level}`;
  const title=!day.inWindow?(past?'Past date':'Not yet published (outside the rolling 30-day window)'):count===0?'No MAX-available direct trains':'Open this date in Plan a trip';
  const label=`${longDate(day.date)}: ${day.inWindow&&count?`${plural(count,'direct MAX train','direct MAX trains')}. `:''}${title}`;
  const inner=day.inWindow?`<span class="cd-count"><b>${count}</b><i>${count===1?'train':'trains'}</i></span>`:`<span class="cd-count"><i>${past?'Past':'Later'}</i></span>`;
  return `<button type="button" class="calendar-day ${state}" data-date="${day.date}" title="${title}" aria-label="${esc(label)}" ${blocked?'disabled':''}><span class="cd-day">${Number(day.date.slice(-2))}</span>${inner}</button>`}).join('');
 $('availabilityCalendar').innerHTML=headers+blanks+cells;
 $('availabilityCalendar').onclick=e=>{const cell=e.target.closest('[data-date]');if(!cell||cell.disabled)return;$('origin').value=$('calendarOrigin').value;$('destination').value=$('calendarDestination').value;$('outbound').value=cell.dataset.date;$('return').value=cell.dataset.date;syncPlanDateLimits();switchView('planView');};
}
