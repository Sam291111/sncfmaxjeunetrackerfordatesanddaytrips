function selectedChanges(){const from=$('hideDirect').checked&&changeLimit>0?1:0;return Array.from({length:changeLimit-from+1},(_,i)=>from+i);}
function setChangeLimit(n){changeLimit=n;document.querySelectorAll('#changeLimit button').forEach(b=>b.setAttribute('aria-pressed',String(Number(b.dataset.limit)===n)));$('hideDirect').disabled=n===0;if(n===0)$('hideDirect').checked=false;}
$('exploreForm').addEventListener('submit',async e=>{
 e.preventDefault();const btn=$('exploreSubmit'),mode=$('exploreMode').value,changes=selectedChanges().map(String);
 btn.disabled=true;btn.textContent='Exploring…';$('exploreStatus').textContent='Checking MAX routes and station locations…';
 try{syncExploreNowFilter();const values={origin:$('exploreOrigin').value,date:$('exploreDate').value,mode,changes:changes.join(','),...connectionQuery(),minimumStayMinutes:$('minimumStayMinutes').value};if(mode==='return')values.returnDate=$('exploreReturnDate').value;if(values.date===iso(new Date())&&$('exploreAfterNow').checked)values.afterNow='true';const p=new URLSearchParams(values),r=await fetch('/api/discovery?'+p),d=await r.json();if(!r.ok)throw Error(d.error||'Discovery search failed');
  drawMap(d);exploreHasSearched=true;const n=d.destinations.length,outboundLabel=longDate(d.date),modeLabel=mode==='daytrip'?'with a same-day MAX return':mode==='return'?`with a MAX return on ${new Date(d.returnDate+'T12:00:00').toLocaleDateString(undefined,{day:'numeric',month:'long'})}`:'one way';
  $('mapHeading').textContent=`${plural(n,'destination','destinations')} ${modeLabel}`;
  $('exploreStatus').innerHTML=`<strong>${plural(n,'destination','destinations')}</strong> from ${esc(d.origin)} · ${esc(outboundLabel)}${mode==='return'?` · returning ${esc(longDate(d.returnDate))}`:''}${d.departureCutoff?` · departures before ${new Date(d.departureCutoff).toLocaleTimeString(undefined,hour23)} excluded`:''} · MAX snapshot ${esc(snapshotLabel(d))}.`;setProvenance(d);
 }catch(err){$('exploreStatus').textContent=err.message;$('destinationMap').className='map-empty';$('destinationMap').textContent='Could not load the destination map.';$('destinationList').innerHTML='';$('discoveryDetails').innerHTML=''}finally{btn.disabled=false;btn.textContent='Explore'}
});let exploreHasSearched=false,changeRefreshTimer;
function refreshExploreSoon(){if(!exploreHasSearched)return;clearTimeout(changeRefreshTimer);changeRefreshTimer=setTimeout(()=>$('exploreForm').requestSubmit(),200);}
$('changeLimit').addEventListener('click',e=>{const b=e.target.closest('[data-limit]');if(!b)return;setChangeLimit(Number(b.dataset.limit));refreshExploreSoon();});
$('hideDirect').addEventListener('change',refreshExploreSoon);
