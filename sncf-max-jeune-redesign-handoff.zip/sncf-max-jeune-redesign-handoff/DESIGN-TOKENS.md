# Design tokens (as implemented in `assets/style.css`)

## Colour

| Token | Value | Use |
|---|---|---|
| `--ink` | `#0F2438` | Body text, headings |
| `--muted` | `#33475B` | Secondary text (≈9:1 on white) |
| `--soft` | `#57697B` | Tertiary text (≈5.5:1) |
| `--line` / `--field` / `--line-strong` | `#D5DDE4` / `#B7C3CE` / `#8C9CAB` | Card borders / control borders / input borders |
| `--ground` / `--surface` | `#EEF2F4` / `#FFFFFF` | Page / cards |
| `--teal`, `--teal-ink` | `#0A6B5E`, `#064E43` | Primary action, active states |
| `--teal-tint`, `--teal-wash`, `--teal-line` | `#DDF1EC`, `#E6F4F0`, `#A9D7CC` | MAX badge, selected row, borders |
| `--navy` | `#14325A` | Start-station marker |
| Amber `#FCEBCB` / `#E8C27A` / `#5C3200` | | OUIGO unverified, warnings |
| Grey `#E6EAEE` / `#C3CDD6` / `#26394D` | | Paid |
| Indigo `#E3E5F8` / `#B5BAEA` / `#2B2F7A` | | Night train |
| Change rings 0–5 | `#0A6B5E #2F7F9E #6A63B8 #A23B72 #B45309 #475569` | Ring colour is secondary; the number inside carries the meaning |
| Calendar heat | `#D7ECE7` (1–2), `#A9D7CC` (3–5), `#6FBFAE` (6+) | Dark text on all of them |

## Type

Family: `"IBM Plex Sans", ui-sans-serif, -apple-system, "Segoe UI", system-ui, sans-serif`, with tabular numbers throughout.

| Role | Size / weight |
|---|---|
| Page title | 32 / 600 (28 on mobile) |
| Card title, panel heading | 22 / 600 or 16 / 600 |
| Journey times | 28 / 600 (26 mobile); detail panel times 30 / 600 |
| Body / controls | 15–16 / 500 |
| Secondary | 13.5–14.5 / 400–500 |
| Smallest | 12.5 (badges, direction labels) |

## Shape and spacing

- Radius: cards 14–16, controls 10, chips and badges 999, calendar cells 12.
- Spacing steps used: 4, 6, 8, 12, 16, 20, 24, 32.
- Page: max-width 1280, padding 32/48 (20/16 on ≤800px). Breakpoints at 1000px (Explore stacks) and 800px (single-column forms, direction tabs, compact calendar).
- Touch targets: 44px minimum.

## Component rules

- **Status is never colour-only.** Badges carry a glyph and a word (✓ MAX available, ? OUIGO, unverified, € Paid, ☾ Night train).
- **Selected** = 2px teal border + `--teal-wash` background (rows) or 2px teal border + `--teal-tint` (chips and segmented buttons).
- **Disabled calendar days** use dashed borders, not strike-through.
- **Focus ring** = 3px teal outline, 2px offset, on every interactive element.
