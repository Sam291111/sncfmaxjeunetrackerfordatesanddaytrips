# Implementation guide

## 1. How the port is structured

The original `index.html` is one file: five stacked `<style>` blocks, static markup, and a dense inline script.
The redesign keeps that single-file shape (the server only serves `/` and `/api/*`, so no new routes are needed) and changes three things:

1. **CSS** is replaced wholesale by `assets/style.css` (one stylesheet, design tokens as CSS variables).
2. **Markup** is replaced by `assets/body.html`. Every element ID the JS reads is preserved, and new IDs are added for new controls.
3. **JS** keeps your logic byte-for-byte except nine places, each a file in `snippets/`.

Why not rewrite the JS? Search, discovery, caching, date limits, connection rules and the booking hand-off are working code with their own edge cases. The redesign only needs to change how results are *drawn*.

## 2. Route A: automated (recommended)

```bash
cd "sncf max jeune"
git checkout -b redesign              # or: cp index.html index.html.bak
cp index.html index.original.html     # the script reads this, writes index.html
python3 /path/to/handoff/tools/apply_redesign.py index.original.html index.html
python3 /path/to/handoff/tools/check_ids.py index.html
```

`apply_redesign.py` asserts that every anchor it replaces appears exactly once. If you've edited `index.html` since the audit it stops with a message such as
`[drawMap] anchor found 0 times`. That tells you which snippet to port by hand (route B) while the script handles the rest. Delete `index.original.html` when you're done.

## 3. Route B: manual, in safe increments

Do these in order, committing after each. After every step the app must still load and search.

| Step | Do this | Replace in `index.html` | Check |
|---|---|---|---|
| 1 | Swap CSS and markup | all five `<style>` blocks, and everything between `<body>` and `<script>` | App loads; tabs switch. Forms won't fully work until step 2. |
| 2 | Add helpers | insert `01-helpers.js` after the first line of the script | No console errors on load |
| 3 | Explore "after now" | `syncExploreNowFilter` ← `02-…` | Chip only appears when the date is today |
| 4 | Plan results | in the plan submit handler, the block from `render(d.outbound…` to before `}catch(err)` ← `03-…`; whole `function render` ← `04-…` | Plan search shows timetable cards with badges |
| 5 | Explore detail panels | `renderExploreJourney` ← `05-…` | Outbound/Return panels in the detail card |
| 6 | Map, list, detail | `drawMap` ← `06-…` | Markers, legend counts, list and detail stay in sync |
| 7 | Explore submit + change limit | explore `submit` listener through to `function monthName` ← `07-…` | "Up to N" refreshes results |
| 8 | Calendar | `renderCalendar` ← `08-…` | Heatmap cells; clicking a day opens Plan |
| 9 | Wiring | append `09-ui-wiring.js` at the end of the script; apply the four one-line edits listed below | Dialogs, swap buttons, stepper, mobile direction tabs |

The four one-line edits (the script does these too):

1. Replace every `hour:'2-digit',minute:'2-digit'}` with `hour:'2-digit',minute:'2-digit',hourCycle:'h23'}` (24-hour times).
2. In `syncConnectionControls`, prefix `$('connectionSettingsSummary').textContent=` with `$('rulesButton').classList.toggle('is-custom',none||manual||Boolean(maximum));`.
3. In `switchView`, after `tab.setAttribute('aria-selected',String(active));` add `tab.tabIndex=active?0:-1;`.
4. In `switchView`, before `if(id==='exploreView'&&!$('exploreOrigin').value)` add `syncEchoes();`.

## 4. Verification checklist

Run in **sample mode** first (`SAMPLE_DATA=1 PORT=3000 node server.js`):

- [ ] No errors in the browser console on load, and on every tab.
- [ ] **Plan a trip:** search returns cards; badges show ✓ MAX / ? OUIGO / € Paid; "Show train details" lists legs; Copy leg details and the booking links still work; swap button works.
- [ ] **Plan, narrow window (≤800px):** Outbound / Return switch appears and works.
- [ ] **Where can I go?:** one-way, Same day and Return later all return results. "Stay at least" only shows for Same day. "Only trains leaving after now" only shows when the date is today.
- [ ] Clicking a marker selects the list row; clicking a row updates the detail; "Show more … times" still loads; "Plan this trip →" fills Plan and switches tab.
- [ ] "Up to 0" with no direct results shows the "Allow up to 1 changes" button, and it works.
- [ ] **Best dates:** heatmap renders; clicking an available day opens Plan with that date.
- [ ] **Header:** Transfer rules dialog changes still re-run Explore; the dot appears when settings are not default. Data & caveats shows the latest search provenance.
- [ ] Keyboard: Tab reaches every control; arrow keys move between the three top tabs; Esc closes dialogs.
- [ ] `npm test` (see note in section 6).

Automated version of most of the above:

```bash
pip install playwright && playwright install chromium
APP_URL=http://127.0.0.1:3000 python3 /path/to/handoff/tests/smoke.py
```

It prints one line per check and `ERRORS: none` at the end. Screenshots land in `/tmp`.

## 5. Test with real data before shipping

Sample mode has 5 stations. Real MAX data has hundreds, which the smoke test did **not** exercise. Specifically check:

- **Map density.** Markers are 22px buttons with the change count inside. Around Paris, Lyon and the Rhône valley they may overlap badly. If they do, options in order of effort: shrink markers to 18px; only show markers for the top ~60 by the current sort; or add simple clustering above a threshold.
- **Neighbouring countries.** Brussels, Zürich, Geneva, Luxembourg etc. are drawn outside the France outline (the view covers roughly lon −5.4 to 10 and lat 41 to 51.4). Anything beyond that is clamped to the map edge.
- **Long lists.** The list scrolls inside its panel (max about 776px or 72vh). Check scrolling and the marker-to-row auto-scroll with 150+ rows.
- **Plan results with many options.** Cards are taller than before, so long result lists get longer. Consider capping each group at 5 with a "Show N more" button.

## 6. Behaviour changes to be aware of

- **Times are 24-hour.** (`hourCycle:'h23'`)
- **Changes filter.** Six checkboxes became "Up to N changes" plus a "Hide direct routes" checkbox. Internally it still sends the same `changes=0,1,2` list to the API.
- **Provenance text moved.** The grey "loaded by this app… search completed…" block now lives in Data & caveats → Latest search. The on-page status line keeps only warnings or a one-line snapshot time.
- **Date fields** are still native `<input type=date>` (so locale formatting and validation are unchanged) with the weekday written out underneath.
- **Calendar.** "Past" and "not yet published" cells are now labelled differently. Clicking an available day behaves exactly as before.
- **Fonts.** The mockups use IBM Plex Sans. The app uses `"IBM Plex Sans", system-ui…`, so it falls back to the system font unless Plex is installed. Bundling it needs a static-file route in `server.js` (currently only `/` and `/api/*` are served) and adding the font files to `forge.config.cjs`; I left that out to keep the change to one file.
- **`npm test`:** 17 of 18 tests pass. The failure, `a day trip requires time at the destination before its return` (`test/route-search.test.js:203`), exists without any of these changes. Nothing in this package touches `planner.js` or `server.js`. It's a good first item for the code audit.

## 7. Known rough edges (not yet fixed)

1. **Duplicate sort control.** The "Sort by" chips show three options, and a dropdown beside them for the rest still displays the current value (so it can read "Fewest changes" twice). A placeholder "More…" option would fix it.
2. **Mobile list → detail.** The mockup shows the detail opening in place under the tapped row (accordion). The implementation instead scrolls up to the detail card under the map. Simpler, but a different feel.
3. **Quick-pick stations** in the Explore empty state are only "Paris (all stations)" and "Lyon (all stations)".
4. **Marker labels** appear only on hover/focus/selection to avoid clutter, so there is no always-visible city name on the map apart from the start station and the selected destination.
5. **Sample-mode data looks odd** (35-hour itineraries with 30-hour waits). That's the demo data, not the layout.
6. **No visual regression suite.** Only the functional smoke test.

## 8. Rollback

Route A: `cp index.original.html index.html` (or `git checkout index.html`). Nothing else in the project changed.

## 9. Observations for the code audit (not changed here)

Spotted while porting; verify rather than trust:

- The original global `button{…}` rule plus later one-off overrides caused the `.hidden` / `.minimum-stay-setting{display:flex}` clash (so the minimum-stay field showed on one-way searches). The new stylesheet uses `.hidden{display:none!important}`.
- Calendar click sets both outbound and return to the clicked date (same-day return) in the original. It's preserved, so check whether that's intended.
- `trainlineStationIds` maps only two stations (Lyon Part-Dieu, Paris Gare de Lyon); every other leg falls back to the generic Trainline page.
- `exploreHasSearched` is declared with `let` far below the listeners that read it. It works only because those listeners fire later; it's fragile.
- The pre-existing failing test above.
