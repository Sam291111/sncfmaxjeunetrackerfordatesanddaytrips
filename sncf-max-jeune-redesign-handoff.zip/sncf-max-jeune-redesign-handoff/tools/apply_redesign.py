#!/usr/bin/env python3
"""
Build a redesigned index.html from your ORIGINAL index.html.

  python3 tools/apply_redesign.py path/to/original/index.html path/to/output/index.html

What it does
  1. Keeps every untouched JS function byte-for-byte from your original file.
  2. Swaps in assets/style.css (one stylesheet, replaces all five <style> blocks).
  3. Swaps in assets/body.html (new markup; keeps every element ID the JS uses).
  4. Replaces specific JS functions with snippets/*.js and appends the UI wiring.

Every replacement asserts that its anchor text exists exactly once. If your
index.html has changed since the audit, the script stops and tells you which
anchor failed, so you can port that piece by hand (see IMPLEMENTATION.md).
"""
import re, sys, pathlib

root = pathlib.Path(__file__).resolve().parent.parent
src_path, out_path = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
html = src_path.read_text(encoding='utf-8')
snip = lambda name: (root / 'snippets' / name).read_text(encoding='utf-8').rstrip('\n')

m = re.search(r'<script>\n(.*?)\n</script>', html, re.S)
assert m, 'Could not find the inline <script> block'
js = m.group(1)

def once(text, needle, label):
    n = text.count(needle)
    assert n == 1, f'[{label}] anchor found {n} times (expected 1): {needle[:70]!r}'

def cut(text, start, end, replacement, label):
    once(text, start, label + ' (start)')
    i = text.index(start)
    j = text.index(end, i + len(start)) if end else len(text)
    return text[:i] + replacement + text[j:]

def swap(text, old, new, label, count=1):
    n = text.count(old)
    assert n == count, f'[{label}] expected {count} match(es), found {n}'
    return text.replace(old, new)

# 1. 24-hour times everywhere (matches the mockups and French convention)
js = swap(js, "hour:'2-digit',minute:'2-digit'}", "hour:'2-digit',minute:'2-digit',hourCycle:'h23'}", 'hourCycle', count=js.count("hour:'2-digit',minute:'2-digit'}"))
assert "hourCycle:'h23'" in js

# 2. helpers + state, inserted right after the first line (const $=... etc.)
first_nl = js.index('\n')
js = js[:first_nl + 1] + snip('01-helpers.js') + '\n' + js[first_nl + 1:]

# 3. Explore "only after now": hide the chip unless the date is today
js = cut(js, 'function syncExploreNowFilter(){', '\nfunction syncExploreReturnField', snip('02-syncExploreNowFilter.js'), 'syncExploreNowFilter')

# 4. Header "Transfer rules" button shows a dot when settings are not the defaults
js = swap(js, "$('connectionSettingsSummary').textContent=", "$('rulesButton').classList.toggle('is-custom',none||manual||Boolean(maximum));$('connectionSettingsSummary').textContent=", 'syncConnectionControls')

# 5. Plan submit: new status handling + column headings + provenance dialog
js = cut(js, "render(d.outbound,'outResults');", "}catch(err){$('status').className='status error'", snip('03-plan-submit-success.js'), 'plan submit')

# 6. Plan results cards
js = cut(js, 'function render(data,target){', "\ndocument.addEventListener('click',async event=>{const button=event.target.closest('[data-copy-train-details]')", snip('04-render-plan-results.js'), 'render')

# 7. Tabs: roving tabindex + date echoes after programmatic date changes
js = swap(js, "tab.setAttribute('aria-selected',String(active));", "tab.setAttribute('aria-selected',String(active));tab.tabIndex=active?0:-1;", 'switchView tabindex')
js = swap(js, "if(id==='exploreView'&&!$('exploreOrigin').value)", "syncEchoes();if(id==='exploreView'&&!$('exploreOrigin').value)", 'switchView echoes')

# 8. Explore: direction panels, map + list + detail, submit, change limit
js = cut(js, 'function renderExploreJourney(journey,label){', '\nfunction renderExploreOption', snip('05-renderExploreJourney.js'), 'renderExploreJourney')
js = cut(js, 'function drawMap(data){', "\n$('exploreForm').addEventListener('submit'", snip('06-drawMap.js'), 'drawMap')
js = cut(js, "$('exploreForm').addEventListener('submit'", 'function monthName', snip('07-explore-submit-and-limits.js') + '\n', 'explore submit')

# 9. Calendar heatmap
js = cut(js, 'function renderCalendar(data){', '\nasync function loadCalendar(){', snip('08-renderCalendar.js'), 'renderCalendar')

# 10. New UI wiring at the very end
js = js + '\n' + snip('09-ui-wiring.js')

css = (root / 'assets' / 'style.css').read_text(encoding='utf-8')
body = (root / 'assets' / 'body.html').read_text(encoding='utf-8')

out = f'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>MAX Jeune Planner</title>
<style>
{css}
</style>
</head>
<body>
{body}
<script>
{js}
</script>
</body>
</html>
'''
out_path.write_text(out, encoding='utf-8')
print(f'wrote {out_path} ({len(out):,} bytes)')
