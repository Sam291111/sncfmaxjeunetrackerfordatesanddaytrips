#!/usr/bin/env python3
"""Check that every $('id') used by the JS exists in the page markup.
Usage: python3 tools/check_ids.py path/to/index.html"""
import re, sys
h = open(sys.argv[1], encoding='utf-8').read()
js = re.search(r'<script>\n(.*?)\n</script>', h, re.S).group(1)
markup = h.replace(js, '')
used = set(re.findall(r"\$\('([A-Za-z][\w-]*)'\)", js))
defined = set(re.findall(r'\bid="([\w-]+)"', markup))
missing = sorted(i for i in used if i not in defined)
print(f'{len(used)} ids referenced by JS, {len(defined)} defined in markup')
if missing:
    print('MISSING:', ', '.join(missing)); sys.exit(1)
print('OK: every referenced id exists')
