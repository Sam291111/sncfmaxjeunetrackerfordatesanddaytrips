import asyncio
from playwright.async_api import async_playwright
import os
URL=os.environ.get('APP_URL','http://127.0.0.1:3100')
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch()
        errs=[]
        async def page(w,h):
            pg=await b.new_page(viewport={'width':w,'height':h})
            pg.on('pageerror',lambda e:errs.append(('pageerror',str(e))))
            pg.on('console',lambda m:errs.append(('console.'+m.type,m.text)) if m.type in('error','warning') else None)
            return pg
        pg=await page(1280,900)
        await pg.goto(URL); await pg.wait_for_timeout(600)
        await pg.screenshot(path='/tmp/n1_plan_empty.png',full_page=True)
        # Plan search
        await pg.fill('#origin','Lyon Part Dieu'); await pg.fill('#destination','Paris Gare de Lyon')
        await pg.click('#submit'); await pg.wait_for_timeout(2500)
        await pg.screenshot(path='/tmp/n2_plan_results.png',full_page=True)
        print('plan journeys',await pg.locator('.journey').count(), '| status:',(await pg.inner_text('#status'))[:90])
        # Explore: tab, one-way
        await pg.click('#tabExplore'); await pg.wait_for_timeout(300)
        print('minStay visible on one-way?',await pg.is_visible('#minimumStaySetting'))
        await pg.screenshot(path='/tmp/n3_explore_empty.png',full_page=True)
        await pg.fill('#exploreOrigin','Lyon Part Dieu')
        await pg.click('#exploreSubmit'); await pg.wait_for_timeout(2500)
        await pg.screenshot(path='/tmp/n4_explore_results.png',full_page=True)
        print('rows',await pg.locator('.destination-row').count(),'markers',await pg.locator('.map-marker').count(),'| heading:',await pg.inner_text('#mapHeading'))
        # click second row -> detail updates
        rows=pg.locator('.destination-row'); 
        if await rows.count()>1:
            await rows.nth(1).click(); await pg.wait_for_timeout(300)
            print('detail after row click:',(await pg.inner_text('.discovery-head h3'))[:50])
        # click a marker
        await pg.locator('.map-marker').first.click(); await pg.wait_for_timeout(300)
        print('detail after marker click:',(await pg.inner_text('.discovery-head h3'))[:50])
        # same-day mode
        await pg.click('[data-mode=daytrip]'); await pg.wait_for_timeout(2500)
        print('minStay visible on same-day?',await pg.is_visible('#minimumStaySetting'),'| heading:',await pg.inner_text('#mapHeading'))
        await pg.screenshot(path='/tmp/n5_explore_daytrip.png',full_page=True)
        # stepper
        await pg.click('#stayUp'); await pg.wait_for_timeout(2500); print('stay label:',await pg.inner_text('#stayOutput'))
        # limit 0 -> maybe empty state
        await pg.click('[data-limit="0"]'); await pg.wait_for_timeout(2500)
        print('limit0 rows',await pg.locator('.destination-row').count(),'| raise btn?',await pg.locator('[data-raise-limit]').count())
        await pg.screenshot(path='/tmp/n6_explore_limit0.png',full_page=True)
        # plan this trip button (set limit back to 2 first)
        await pg.click('[data-limit="2"]'); await pg.wait_for_timeout(2500)
        await pg.click('[data-plan-trip]'); await pg.wait_for_timeout(300)
        print('after plan-this-trip: view active tab=',await pg.get_attribute('#tabPlan','aria-selected'),'dest=',await pg.input_value('#destination'),'echo=',await pg.inner_text('#outboundEcho'))
        # Dates
        await pg.click('#tabDates'); await pg.fill('#calendarOrigin','Lyon Part Dieu'); await pg.fill('#calendarDestination','Paris Gare de Lyon')
        await pg.click('#calendarSubmit'); await pg.wait_for_timeout(2000)
        await pg.screenshot(path='/tmp/n7_dates.png',full_page=True)
        print('calendar cells',await pg.locator('.calendar-day').count())
        # dialogs
        await pg.click('#caveatsButton'); await pg.wait_for_timeout(200)
        await pg.screenshot(path='/tmp/n8_caveats.png')
        await pg.keyboard.press('Escape')
        await pg.click('#rulesButton'); await pg.select_option('#minConnectionMode','manual'); await pg.wait_for_timeout(200)
        print('manual field visible:',await pg.is_visible('#manualConnectionField'),'| rules dot:',await pg.evaluate("document.getElementById('rulesButton').classList.contains('is-custom')"))
        await pg.screenshot(path='/tmp/n9_rules.png')
        await pg.keyboard.press('Escape')
        # Mobile
        m=await page(390,844)
        await m.goto(URL); await m.wait_for_timeout(500)
        await m.fill('#origin','Lyon Part Dieu'); await m.fill('#destination','Paris Gare de Lyon'); await m.click('#submit'); await m.wait_for_timeout(2500)
        await m.screenshot(path='/tmp/m1_plan.png',full_page=True)
        await m.click('#dirBack'); await m.wait_for_timeout(200)
        print('mobile return col visible:',await m.is_visible('#colBack'),'out hidden:',not await m.is_visible('#colOut'))
        await m.click('#tabExplore'); await m.fill('#exploreOrigin','Lyon Part Dieu'); await m.click('#exploreSubmit'); await m.wait_for_timeout(2500)
        await m.screenshot(path='/tmp/m2_explore.png',full_page=True)
        # horizontal overflow check
        for name,pgx in (('desktop',pg),('mobile',m)):
            ov=await pgx.evaluate("document.documentElement.scrollWidth-document.documentElement.clientWidth")
            print(name,'horizontal overflow px:',ov)
        print('ERRORS:',errs if errs else 'none')
        await b.close()
asyncio.run(main())
