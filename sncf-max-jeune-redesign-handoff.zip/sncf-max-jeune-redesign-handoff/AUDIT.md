# UX audit and what changed

Based on the app running in sample mode at 1280px and 390px (screenshots in `screenshots/before`).

## Where can I go? (the confusing tab)

| Problem | Change |
|---|---|
| Tab name didn't say what you get | Renamed "Where can I go?" with a one-line promise under the title |
| Four separately styled blocks sat between the Explore button and the results (after-now checkbox, minimum stay, six change checkboxes, a three-line hint); the map started at about y=560 on desktop and past y=1000 on mobile | One form row, one filter row. Results start immediately below |
| Six "N changes" checkboxes plus a hint explaining "turn off 0–2 to focus on longer routes" | "Up to N train changes" selector, plus an optional "Hide direct routes" checkbox |
| **Bug:** "Minimum time at destination" showed for One way (`.hidden{display:none}` lost to a later `.minimum-stay-setting{display:flex}`) | `.hidden{display:none!important}`; field only for Same day, now a "Stay at least 3 h" stepper |
| "Only trains leaving after now" sat orphaned, disabled with an explanatory hint when the date wasn't today | Shown only when the date is today |
| Map was a hand-drawn blob, hover-only tooltips, six colours carrying all the meaning | Real simplified France outline; markers are buttons with the change count inside; colour is secondary; labels on hover/focus/selected |
| List on the right, detail under the map on the left | List left; map and detail stacked on the right so selecting never scrolls you away (desktop) |
| "1 destinations", "2 destinations one way" | Pluralised; "2 destinations with a same-day MAX return" |
| Empty states gave no way forward | "Allow up to N changes" button; quick-pick station chips |

## Plan journey

| Problem | Change |
|---|---|
| MAX / OUIGO / paid status buried in 11px text at the bottom of each card | Status badges on every card: ✓ MAX · ? OUIGO unverified · € Paid · ☾ Night |
| Headline "Sun, Oct 11, 09:10 AM → Mon, Oct 12, 09:00 PM" wrapped at 18px | Timetable row: `09:10 → 21:00 +1d`, duration and changes right-aligned |
| "If paid rail is off, show closest stops" always visible | Only appears when paid rail is off |
| Two long-sentence checkboxes | Switches with short labels |
| Outbound and return in two columns on every width | Side by side on desktop with sticky headings; Outbound / Return switch on mobile |
| "No results" with no next step | "Find a better date" jumps to Best dates |

## Best dates

| Problem | Change |
|---|---|
| "0 available of 0" | A big count with "trains" under it; "0" cells are dashed |
| Diagonal strike-through across the date digits | Removed; blocked states are dashed borders |
| "No MAX" and "outside window" looked alike | Past ("Past") and not-yet-published ("Later") are labelled and styled differently from "no train" |

## System-wide

| Problem | Change |
|---|---|
| ~215px hero before any input; tab bar straddled the hero edge | Slim header with brand, tabs and two buttons |
| Vague tab labels | "Plan a trip", "Where can I go?", "Best dates" |
| "Connection preferences" collapsed above every form | "Transfer rules" dialog from the header, with a dot when non-default |
| Grey provenance wall after every search | Moved into "Data & caveats → Latest search"; on-page line keeps warnings or a short snapshot time |
| 31 declarations at 10–12px; hint grey ≈3.7:1 on the page background | 12.5px minimum (most hints 13–13.5px); muted text #33475B (well above 4.5:1) |
| Ambiguous `10/11/2026` | Weekday spelled out under each date field |
| Five stacked `<style>` blocks (source of the `.hidden` clash) | One stylesheet with tokens |
| Global `button{…}` forced every button to look primary | Buttons styled by role: `.btn-primary`, `.btn-secondary`, segmented, chips, icon buttons |
| 44px minimum touch targets | Applied to all controls |
